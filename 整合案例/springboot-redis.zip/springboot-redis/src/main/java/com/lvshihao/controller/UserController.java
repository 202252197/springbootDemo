package com.lvshihao.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lvshihao.api.UserApi;
import com.lvshihao.entity.User;

@Controller
public class UserController {
	@Autowired
	UserApi userApi;
	@RequestMapping("/index")
	public String index(){
		return "index";
	}
	@RequestMapping("/installAll")
	public void installAll(){
		userApi.insterAll();
	}
	@ResponseBody
	@RequestMapping("/selectlAll")
	public ArrayList<User> selectlAll(){
		ArrayList<User> user=userApi.selectAll();
		return user;
	}
}
