package com.lvshihao.service;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.lvshihao.api.UserApi;
import com.lvshihao.dao.UserMapper;
import com.lvshihao.entity.User;
@Service
public class UserService implements UserApi {
	@Autowired
	UserMapper userMapper;
    @Autowired
	RedisTemplate<Object, Object> redisTemplate;
	@Resource(name = "redisTemplate")
	ValueOperations<Object, Object> valOpsObj;
	
	@Override
	public void insterAll() {
		// TODO Auto-generated method stub
		redisTemplate.opsForValue().set("user", JSON.toJSONString(userMapper.selectAll()));
	}

	@Override
	public ArrayList<User> selectAll() {
		ArrayList<User> user=JSON.parseObject((String) redisTemplate.opsForValue().get("user"),new TypeReference<ArrayList<User>>(){});
		return user;
	}

}
