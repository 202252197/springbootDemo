package com.lvshihao.dao;

import java.util.ArrayList;

import com.lvshihao.entity.User;

public interface UserMapper {
	public void insterAll();
	public ArrayList<User> selectAll();
}
