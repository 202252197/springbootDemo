package com.lvshihao.api;

import java.util.ArrayList;

import com.lvshihao.entity.User;

public interface UserApi {
	public void insterAll();
	public ArrayList<User> selectAll();
}
